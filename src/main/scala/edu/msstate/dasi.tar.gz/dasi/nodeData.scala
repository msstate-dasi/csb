package edu.msstate.dasi

/***
  *
  * @param data Concatenated string with SourceIP-DestIP:Port:Connection_Type
  */
case class nodeData(data: String = "")
